
#include "listlnk.h"
#include <iostream>

using namespace std;

template<class DT>
ListNode<DT>::ListNode(const DT& nodeData, ListNode* nextPtr)
{
    
}


template<class DT>
List<DT>::List(int ignored)
{

}

//------------------------------------------------

template<class DT>
List<DT>::~List()
{
    
}

//------------------------------------------------


template<class DT>
void List<DT>::insert(const DT& newData)
{
    
}

//------------------------------------------------


template<class DT>
void List<DT>::remove()
{
    
}


//------------------------------------------------


template<class DT>
void List<DT>::replace(const DT& newData)
{

}

//------------------------------------------------


template<class DT>
void List<DT>::clear()
{
    
}

//------------------------------------------------


template<class DT>
bool List<DT>::isEmpty() const
{
    
}

//------------------------------------------------


template<class DT>
bool List<DT>::isFull() const
{
    
}

//------------------------------------------------


template<class DT>
void List<DT>::gotoBeginning()
{
    
}

//------------------------------------------------


template<class DT>
void List<DT>::gotoEnd()
{
    
}

//------------------------------------------------


template<class DT>
bool List<DT>::gotoNext()
{
    
}

//------------------------------------------------


template<class DT>
bool List<DT>::gotoPrior()
{
    
}

//------------------------------------------------


template<class DT>
DT List<DT>::getCursor() const
{
    
}

template<class DT>
void List<DT>::showStructure() const
{
    
}