#include <iostream>
#include "listdbl.h"

using namespace std;

template < class DT >
ListNode<DT>::ListNode(const DT& data, ListNode* priorPtr, ListNode* nextPtr)
{

}

// Constructor
template < class DT >
List<DT>::List(int ignored)
{

}

// Destructor
template < class DT >
List<DT>::~List()
{

}


//------------ List manipulation operations ------------------

// Insert after cursor
template < class DT >
void List<DT>::insert(const DT& newDataItem)
{

}

// Remove data item
template < class DT >
void List<DT>::remove()
{

}

// Replace data item
template < class DT >
void List<DT>::replace(const DT& newElement)
{

}

// Clear list
template < class DT >
void List<DT>::clear()
{

}


//------------ List status operations ------------------

// List is empty
template < class DT >
bool List<DT>::isEmpty() const
{

}

// List is full
template < class DT >
bool List<DT>::isFull() const
{

}


//------------ List manipulation operations ------------------

// Go to beginning
template < class DT >
void List<DT>::gotoBeginning()
{

}

// Go to end
template < class DT >
void List<DT>::gotoEnd()
{

}

// Go to next data item
template < class DT >
bool List<DT>::gotoNext()
{

}

// Go to prior data item
template < class DT >
bool List<DT>::gotoPrior()
{

}


template < class DT >
DT List<DT>::getCursor() const
{
	
}


//-----------------------------------------------------------

template < class DT >
void List<DT>::showStructure() const
{

}