//--------------------------------------------------------------------
//
//  Laboratory 14                                          wtgraph.cpp
//
//  Implementation of the Weighted Graph ADT
//
//--------------------------------------------------------------------
#include "wtgraph.h"

//--------------------------------------------------------------------

WtGraph::WtGraph(int maxNumber)
{

}

WtGraph::~WtGraph()
{

}

//--------------------------------------------------------------------

int WtGraph::getIndex(char* v)
{
	
}

int WtGraph::getEdge(int row, int col)
{

}

void WtGraph::setEdge(int row, int col, int wt) 
{

}

//--------------------------------------------------------------------

void WtGraph::insertVertex(Vertex newVertex)
{
	
}

void WtGraph::insertEdge(char* v1, char* v2, int wt)
{
	
}

//--------------------------------------------------------------------

bool WtGraph::retrieveVertex(char* v, Vertex& vData)
{

}

bool WtGraph::getEdgeWeight(char* v1, char* v2, int& wt)
{

}

//--------------------------------------------------------------------

void WtGraph::removeVertex(char* v)
{

}

void WtGraph::removeEdge(char* v1, char* v2)
{

}

//--------------------------------------------------------------------

void WtGraph::clear()
{

}

bool WtGraph::isEmpty() const
{

}

bool WtGraph::isFull() const
{

}

//--------------------------------------------------------------------

void WtGraph::showStructure()

// Outputs a graph's vertex list (w/ color) and adjacency matrix.
// This operation is intended for testing/debugging purposes only.

{

}

//--------------------------------------------------------------------


// int WtGraph::getPath(int row, int col)
// {

// }

// void WtGraph::setPath(int row, int col, int wt) {

// }

// void WtGraph::computePaths() 
// {

// }